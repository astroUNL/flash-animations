Flash Exploit Command Line 1.0
Based On: Flash Exploit 1.19 [IRON]
Copyright M-Gate Labs 2008
http://www.mgatelabs.com

For more information please visit http://swf2svg.3d2toy.com